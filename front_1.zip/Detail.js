import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { Nav, Button, Tab, Tabs } from 'react-bootstrap';
import {useState, useEffect} from 'react';
import axios from 'axios';

function Detail() { //dish_num
  // hook
  const {state} = useLocation();
  console.log(state)

  let navigate = useNavigate();
  // 게시글 하단 탭
  let [tab, setTab] = useState('');
  let [레시피, set레시피] = useState('');
  let [영상, set영상] = useState('');
  // 좋아요
  let [like, setLike] = useState(false);
  // 주소 파라미터
  // let {id} = useParams();
  // let dish = realData.find((result) => 
  //     result.dish_num === id
  // );
  let [reply, setReply] = useState([]);

  // 게시글 데이터 가져오기
  let [postData, setPostData] = useState([]);


  useEffect(()=>{
    axios.get("http://192.168.0.23:8080/api/dish/get/"+ state +"/6")
    .then((response)=>{
      console.log(response.data)
      setPostData(response.data.result)
    })
    .catch((err)=>{
      console.log(err)
    })
  }, [state])
  console.log(postData)

  // useEffect(()=>setSimple(realData),[realData])

  // 댓글
  function sendMSG() {
    const fdata = new FormData();
    fdata.append('content', reply);
    axios.post("http://192.168.0.23:8080/api/dish/comm/add/6/"+ state,
    fdata)
      .then((response) => {
      console.log(response);
    })
    .catch((error)=>{
      console.log(error + '에러')
    });
  }

  let [inputText, setInputText] = useState();

  return (
    <>
    <Button className='back' variant="light" onClick={()=>{navigate(-1)}}>{'<<'} 뒤로가기</Button>
      <div className="container">
       {postData && (
        <div className='all'>
          <h1 className='nameD'>{postData.dish_name}</h1>
            <div className='detailR'>조회: {postData.hit}</div>
            {/* <div className='detailR'>작성자: {dish.writer}</div>
            <div className='detailR'>작성일: {dish.date}</div> */}
            
          <div className='middle'>
            <img src={postData.mainIMG} width="100%" /><br/>
          <div className='small'>
            <span onClick={(e)=>{
              e.stopPropagation()
              setLike(!like)
              console.log(like)
            }}>
            <span className='mouse'>{like === true ? '❤️' : '🤍'}</span>
            {
              like === true ?
              postData.dish_like +1
              : postData.dish_like
            }
            </span>
            <span className='small'> 😋{postData.ate}</span>
          </div><br/>
        </div>
      </div>
      )}
      <Tabs
        defaultActiveKey="레시피"
        id="fill-tab-example"
        className="mb-3"
        fill
      >
        <Tab eventKey="레시피" title="레시피">
          {postData && '레시피 고민중'
        //     postData.recipe.map((order, i)=>{
        //     return(
        //       <>
        //       <p><img src={postData.imgList[i]} className='imgSize'></img></p>
        //       <h4>{order}</h4>
        //       <br/><br/>
        //       </>
        //   )}
        // )
        }
        </Tab>
        <Tab eventKey="재료" title="재료">
          {postData && postData.ingredient}
        </Tab>
        <Tab eventKey="댓글" title="댓글">
          {postData &&
          reply.map((r, i)=>{
              return(
                <div>
                  <h6 className='oneline'>{r}</h6>
                  <div className='outline'>
                  <h6 className='arrReply'>{postData.writer} | {postData.date}</h6>
                  <span className='blind'>-----</span>
                    <button className='delrepB' onClick={()=>{
                      let del = [...reply];
                      del.splice(i,1);
                      setReply(del);
                    }}>삭제</button></div>
                  <hr/>
                </div>
              )
            })
          }
          <div className='nameD'>
            <input className='replyTab' type="text" onChange={(e) => {
              setInputText(e.target.value);
            }}/><span className='blind'>-</span>
            <button className='replyB' onClick={() => {
              // let copy = [...reply];
              inputText == '' ? alert('댓글을 입력하세요') : reply.push(inputText);
              // setReply(copy);
              setInputText('');
              sendMSG();
            }}>등록</button>
            <br/><br/>
          </div>
        </Tab>
      </Tabs>
          </div>
      </>
  );
}

// function TabCom({reply, setReply, input, setInput}){
//   return(
    
//     );
// }
export default Detail;
